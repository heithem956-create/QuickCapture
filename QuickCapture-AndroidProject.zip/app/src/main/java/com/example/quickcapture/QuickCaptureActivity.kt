/*
 * QuickCaptureActivity.kt
 * Android App: Double-Press Power Button Lock-Screen Photo Capture (Kotlin + CameraX)
 *
 * =========================================================================================
 * 1. ADD DEPENDENCIES IN app/build.gradle.kts:
 * =========================================================================================
 * dependencies {
 *     val cameraxVersion = "1.3.4"
 *     implementation("androidx.camera:camera-core:$cameraxVersion")
 *     implementation("androidx.camera:camera-camera2:$cameraxVersion")
 *     implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
 *     implementation("androidx.camera:camera-view:$cameraxVersion")
 *     implementation("androidx.appcompat:appcompat:1.7.0")
 *     implementation("androidx.core:core-ktx:1.13.1")
 * }
 *
 * =========================================================================================
 * 2. CONFIGURE AndroidManifest.xml:
 * =========================================================================================
 * <manifest xmlns:android="http://schemas.android.com/apk/res/android"
 *     package="com.example.quickcapture">
 *
 *     <uses-feature android:name="android.hardware.camera.any" android:required="true" />
 *     <uses-permission android:name="android.permission.CAMERA" />
 *     <uses-permission android:name="android.permission.VIBRATE" />
 *     <uses-permission android:name="android.permission.WAKE_LOCK" />
 *     <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
 *     <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" />
 *     <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
 *     <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT" />
 *     <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
 *         android:maxSdkVersion="28" />
 *
 *     <application
 *         android:allowBackup="true"
 *         android:label="QuickCapture"
 *         android:theme="@style/Theme.AppCompat.NoActionBar">
 *
 *         <activity
 *             android:name=".QuickCaptureActivity"
 *             android:exported="true"
 *             android:showWhenLocked="true"
 *             android:turnScreenOn="true"
 *             android:launchMode="singleTop"
 *             android:excludeFromRecents="true">
 *
 *             <intent-filter>
 *                 <action android:name="android.intent.action.MAIN" />
 *                 <category android:name="android.intent.category.LAUNCHER" />
 *             </intent-filter>
 *
 *             <!-- Triggered natively by Android when double-pressing the Power button while locked -->
 *             <intent-filter>
 *                 <action android:name="android.media.action.STILL_IMAGE_CAMERA_SECURE" />
 *                 <category android:name="android.intent.category.DEFAULT" />
 *             </intent-filter>
 *
 *             <!-- Triggered when double-pressing the Power button while unlocked -->
 *             <intent-filter>
 *                 <action android:name="android.media.action.STILL_IMAGE_CAMERA" />
 *                 <category android:name="android.intent.category.DEFAULT" />
 *             </intent-filter>
 *         </activity>
 *
 *         <!-- Optional fallback foreground service for OEMs that lock the double-tap gesture -->
 *         <service
 *             android:name=".PowerButtonFallbackService"
 *             android:exported="false"
 *             android:foregroundServiceType="camera" />
 *     </application>
 * </manifest>
 */

package com.example.quickcapture

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class QuickCaptureActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var autoCaptureTriggered = false

    companion object {
        private const val TAG = "QuickCapture"
        const val EXTRA_AUTO_CAPTURE = "extra_auto_capture"
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        if (cameraGranted) {
            startCamera()
        } else {
            Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableLockScreenWake()
        setupUi()

        cameraExecutor = Executors.newSingleThreadExecutor()

        // Automatically capture if launched via double-press power button intent or fallback service
        autoCaptureTriggered = isLaunchedFromPowerShortcut(intent)

        if (hasRequiredPermissions()) {
            startCamera()
        } else {
            requestRequiredPermissions()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isLaunchedFromPowerShortcut(intent)) {
            autoCaptureTriggered = true
            capturePhoto()
        }
    }

    /**
     * Allows the activity to display over the lock screen and wake the display
     * when triggered while the phone is locked/closed.
     */
    private fun enableLockScreenWake() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun isLaunchedFromPowerShortcut(launchIntent: Intent?): Boolean {
        val action = launchIntent?.action ?: return false
        return action == MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE ||
            action == MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA ||
            launchIntent.getBooleanExtra(EXTRA_AUTO_CAPTURE, false)
    }

    private fun setupUi() {
        val rootLayout = FrameLayout(this)

        previewView = PreviewView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(previewView)

        val controlsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                setMargins(32, 32, 32, 64)
            }
        }

        statusText = TextView(this).apply {
            text = "Ready — Double-press Power button while locked to auto-capture"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 16, 16, 24)
        }
        controlsLayout.addView(statusText)

        val captureButton = Button(this).apply {
            text = "Take Photo Now"
            setOnClickListener { capturePhoto(closeAfterCapture = false) }
        }
        controlsLayout.addView(captureButton)

        val toggleServiceButton = Button(this).apply {
            text = "Start Background Power-Toggle Service"
            setOnClickListener {
                val serviceIntent = Intent(this@QuickCaptureActivity, PowerButtonFallbackService::class.java)
                ContextCompat.startForegroundService(this@QuickCaptureActivity, serviceIntent)
                Toast.makeText(
                    this@QuickCaptureActivity,
                    "Fallback service started",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        controlsLayout.addView(toggleServiceButton)

        rootLayout.addView(controlsLayout)
        setContentView(rootLayout)
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageCapture
                )

                // If launched from the lock-screen power double-press, take photo immediately
                if (autoCaptureTriggered) {
                    autoCaptureTriggered = false
                    Handler(Looper.getMainLooper()).postDelayed({
                        capturePhoto(closeAfterCapture = true)
                    }, 350L) // Brief delay so sensor auto-exposure settles
                }
            } catch (exc: Exception) {
                Log.e(TAG, "Camera binding failed", exc)
            }
        }, ContextCompat.getMainLooper(this))
    }

    private fun capturePhoto(closeAfterCapture: Boolean = true) {
        val imageCapture = imageCapture ?: return

        val name = SimpleDateFormat(FILENAME_FORMAT, Locale.US)
            .format(System.currentTimeMillis())

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/QuickCapture")
            }
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        statusText.text = "Capturing photo..."

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainLooper(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                    statusText.text = "Capture failed: ${exc.message}"
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    vibrateConfirmation()
                    statusText.text = "Saved to Pictures/QuickCapture/IMG_$name.jpg"
                    Toast.makeText(
                        baseContext,
                        "Photo saved!",
                        Toast.LENGTH_SHORT
                    ).show()

                    if (closeAfterCapture) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            finish()
                        }, 600L)
                    }
                }
            }
        )
    }

    private fun vibrateConfirmation() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(120L, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(120L)
        }
    }

    private fun hasRequiredPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}

/**
 * Optional Foreground Service fallback:
 * Detects a rapid screen OFF -> ON toggle (double power press within 650ms)
 * on devices where the OEM restricts changing the default double-tap camera shortcut.
 */
class PowerButtonFallbackService : Service() {

    private var lastToggleTimestamp = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_OFF || intent.action == Intent.ACTION_SCREEN_ON) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastToggleTimestamp in 80L..650L) {
                    lastToggleTimestamp = 0L
                    launchLockScreenCapture(context)
                } else {
                    lastToggleTimestamp = now
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, filter)
    }

    private fun launchLockScreenCapture(context: Context) {
        val captureIntent = Intent(context, QuickCaptureActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(QuickCaptureActivity.EXTRA_AUTO_CAPTURE, true)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            captureIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            pendingIntent.send()
        } catch (e: PendingIntent.CanceledException) {
            context.startActivity(captureIntent)
        }
    }

    private fun startAsForeground() {
        val channelId = "quick_capture_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Quick Capture Standby",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("QuickCapture Active")
            .setContentText("Listening for double power-button press")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(1001, notification)
    }

    override fun onDestroy() {
        unregisterReceiver(screenReceiver)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}