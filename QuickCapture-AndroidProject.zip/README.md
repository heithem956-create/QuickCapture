# QuickCapture Android Project

This project builds the **QuickCapture** Android app (`app-debug.apk`) for taking photos over the lock screen by double-pressing the power button.

## Option 1: Build the APK in the Cloud (No PC or Android Studio Needed)
1. Unzip `QuickCapture-AndroidProject.zip`.
2. Create a new repository on [GitHub](https://github.com/new) and upload all files from this folder (including `.github/workflows/build-apk.yml`).
3. Open the **Actions** tab in your GitHub repository — the **Build Debug APK** workflow will run automatically.
4. Once finished (~2 minutes), download **QuickCapture-debug-apk** from the workflow run's **Artifacts** section, extract `app-debug.apk`, and install it on your phone.

## Option 2: Build Locally in Android Studio
1. Unzip `QuickCapture-AndroidProject.zip` and open the folder in **Android Studio**.
2. Wait for Gradle Sync to finish, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Find the installable APK at `app/build/outputs/apk/debug/app-debug.apk`.
